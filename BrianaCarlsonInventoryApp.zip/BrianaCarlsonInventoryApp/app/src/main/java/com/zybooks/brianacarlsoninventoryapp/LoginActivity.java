package com.zybooks.brianacarlsoninventoryapp;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

	Activity activity;
    Button LoginButton, RegisterButton;
    EditText Email, Password;
    String NameHolder, PhoneNumberHolder, EmailHolder, PasswordHolder;
    Boolean EmptyHolder;
    SQLiteDatabase db;
    UserDatabase handler;
    String TempPassword = "NOT_FOUND" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        LoginButton = findViewById(R.id.signinButton);
        RegisterButton = findViewById(R.id.registerButton);
        Email = findViewById(R.id.editTextEmailAddress);
        Password = findViewById(R.id.editTextPassword);
        handler = new UserDatabase(this);

        // Adding click listener to sign in
        LoginButton.setOnClickListener(view -> {
            // Call Login function
            LoginFunction();
        });

        // Adding click listener to register
        RegisterButton.setOnClickListener(view -> {
            // Opening new RegisterActivity
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    // Login function
    public void LoginFunction() {
		String message = CheckEditTextNotEmpty();

        if(!EmptyHolder) {
            // Opening SQLite database write permission
            db = handler.getWritableDatabase();

            // Adding search email query to cursor
            Cursor cursor = db.query(UserDatabase.TABLE_NAME, null, " " + UserDatabase.COLUMN_3_EMAIL + "=?", new String[]{EmailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    // Storing Password and Name associated with entered email
                    TempPassword = cursor.getString(cursor.getColumnIndex(UserDatabase.COLUMN_4_PASSWORD));
                    NameHolder = cursor.getString(cursor.getColumnIndex(UserDatabase.COLUMN_1_NAME));
                    PhoneNumberHolder = cursor.getString(cursor.getColumnIndex(UserDatabase.COLUMN_2_PHONE_NUMBER));

                    // Closing cursor.
                    cursor.close();
                }
            }
			handler.close();

            // Calling method to check final result
            CheckFinalResult();
        } else {
            //If any of login EditText empty then this block will be executed.
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    // Checking editText fields are not empty.
	public String CheckEditTextNotEmpty() {
		// Getting value from fields and storing into string variable
		String message = "";
		EmailHolder = Email.getText().toString().trim();
		PasswordHolder = Password.getText().toString().trim();

		if (EmailHolder.isEmpty()){
			Email.requestFocus();
			EmptyHolder = true;
			message = "User Email is Empty";
		} else if (PasswordHolder.isEmpty()){
			Password.requestFocus();
			EmptyHolder = true;
			message = "User Password is Empty";
		} else {
			EmptyHolder = false;
		}
		return message;
	}

    // Checking entered password from SQLite database email associated password
    public void CheckFinalResult(){
        if(TempPassword.equalsIgnoreCase(PasswordHolder)) {
            Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            // Sending Name to ItemsListActivity using intent
            Bundle bundle = new Bundle();
            bundle.putString("user_name", NameHolder);
            bundle.putString("user_email", EmailHolder);
            bundle.putString("user_phone", PhoneNumberHolder);

            // Going to ItemsListActivity after login success message
            Intent intent = new Intent(LoginActivity.this, ItemsListActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);

            // Empty editText  after login successful and close database
            EmptyEditTextAfterDataInsert();
        } else {
            // Display error message if credentials are not correct
            Toast.makeText(LoginActivity.this,"Incorrect Email or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        TempPassword = "NOT_FOUND" ;
    }

    // Empty edittext after login successful
    public void EmptyEditTextAfterDataInsert() {
        Email.getText().clear();
        Password.getText().clear();
    }
}
